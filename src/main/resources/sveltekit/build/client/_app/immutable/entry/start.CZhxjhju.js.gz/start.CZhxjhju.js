import{a as t}from"../chunks/entry.BtOm4_Lm.js";export{t as start};
